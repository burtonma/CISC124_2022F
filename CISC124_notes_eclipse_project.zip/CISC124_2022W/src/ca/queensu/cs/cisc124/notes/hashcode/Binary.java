package ca.queensu.cs.cisc124.notes.hashcode;

import java.util.Arrays;

/**
 * Simple binary number class that represents non-zero
 * binary values.
 *
 */
public class Binary {
	private boolean[] bits;
    
    public Binary(boolean[] bits) {
        if (bits == null) {
        	throw new NullPointerException();
        }
        this.bits = Arrays.copyOf(bits, bits.length);
    }
    
    public long toDecimal() {
    	long sum = 0;
    	long pow = 1;
    	for (int i = this.bits.length - 1; i >= 0; i--) {
    		boolean b = this.bits[i];
    		if (b) {
    			sum += pow;
    		}
    		pow *= 2;
    	}
    	return sum;
    }
    
    @Override
    public boolean equals(Object obj) {
    	if (this == obj) {
    		return true;
    	}
    	if (!(obj instanceof Binary)) {
    		return false;
    	}
    	Binary other = (Binary) obj;
    	return Arrays.equals(this.bits, other.bits);
    }
    
    @Override
    public int hashCode() {
    	return Arrays.hashCode(this.bits);
    }
}
