package ca.queensu.cs.cisc124.notes.enums;

/**
 * A simple enumeration of the days of the week.
 *
 */
public enum Day {
	SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY;
}
