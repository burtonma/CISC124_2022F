package ca.queensu.cs.cisc124.notes.generics.basics;

/**
 * An array-based implementation of the {@code Queue} interface.
 *
 * @param <E> the type of elements in the queue
 */
public class ArrayQueue<E> implements Queue<E> {

	// the default capacity of the queue
	private static final int DEFAULT_CAPACITY = 16;

	// the array that stores the queue
	private Object[] arr;

	// the index of the element at the front of the queue
	private int front;

	// the index of the element at the back of the queue
	private int back;

	// the number of elements in the queue
	private int size;

	/**
	 * Initialize an empty queue.
	 */
	public ArrayQueue() {
		this.arr = new Object[ArrayQueue.DEFAULT_CAPACITY];
		this.front = 0;
		this.back = -1;
		this.size = 0;
	}

	@Override
	public int size() {
		return this.size;
	}

	@Override
	public void enqueue(E elem) {
		if (this.size == this.arr.length) {
			Object[] tmp = new Object[this.arr.length * 2];
			for (int i = 0; i < this.size; i++) {
				tmp[i] = this.arr[(this.front + i) % this.arr.length];
			}
			this.arr = tmp;
			this.front = 0;
			this.back = this.size - 1;
		}
		this.back = (this.back + 1) % this.arr.length;
		this.arr[this.back] = elem;
		this.size++;
	}

	@Override
	public E dequeue() {
		if (this.isEmpty()) {
			throw new RuntimeException("dequeued an empty queue");
		}
		Object elem = this.arr[this.front];

		// null out the value stored in the array
		this.arr[this.front] = null;
		this.front = (this.front + 1) % this.arr.length;
		this.size--;
		return (E) elem;
	}

	@Override
	public E front() {
		if (this.isEmpty()) {
			throw new RuntimeException("no front element in an empty queue");
		}
		return (E) this.arr[this.front];
	}

	@Override
	public E back() {
		if (this.isEmpty()) {
			throw new RuntimeException("no back element in an empty queue");
		}
		return (E) this.arr[this.back];
	}

	@Override
	public String toString() {
		StringBuilder b = new StringBuilder("[");
		for (int i = 0; i < this.size - 1; i++) {
			int index = (this.front + i) % this.arr.length;
			b.append(this.arr[index].toString());
			b.append(", ");
		}
		if (!this.isEmpty()) {
			b.append(this.back());
		}
		b.append("]");

		return b.toString();
	}

	public static void main(String[] args) {
		Queue<Integer> q = new ArrayQueue<>();
		System.out.println(q);
		q.enqueue(1);
		System.out.println(q);
		q.enqueue(2);
		System.out.println(q);
		System.out.println("dequeue = " + q.dequeue());
		System.out.println(q);
		System.out.println("dequeue = " + q.dequeue());
		System.out.println(q);
		q.enqueue(3);
		System.out.println(q);
		System.out.println("dequeue = " + q.dequeue());
		System.out.println(q);

		q.enqueue(4);
		System.out.println(q);
		q.enqueue(5);
		System.out.println(q);
		q.enqueue(6);
		System.out.println(q);
		q.enqueue(7);
		System.out.println(q);

		System.out.println("dequeue = " + q.dequeue());
		System.out.println(q);
		System.out.println("dequeue = " + q.dequeue());
		System.out.println(q);
		System.out.println("dequeue = " + q.dequeue());
		System.out.println(q);

		q.enqueue(8);
		System.out.println(q);
		q.enqueue(9);
		System.out.println(q);

		System.out.println("dequeue = " + q.dequeue());
		System.out.println(q);
		System.out.println("dequeue = " + q.dequeue());
		System.out.println(q);
		System.out.println("dequeue = " + q.dequeue());
		System.out.println(q);

		q.enqueue(10);
		System.out.println(q);
		q.enqueue(11);
		System.out.println(q);

		System.out.println("dequeue = " + q.dequeue());
		System.out.println(q);
		System.out.println("dequeue = " + q.dequeue());
		System.out.println(q);

	}
}
