package ca.queensu.cs.cisc124.notes.inheritance.shapes;

public class ShapeAnalysis {

	/**
	 * Uniformly scale the specified shape so that the final width of the shape
	 * is one.
	 *  
	 * @param s the shape to scale
	 */
	public static void normalizeWidth(Shape s) {
        double h = s.height() / s.width();
        double w = 1.0;
        s.setDimensions(w, h);
    }
}
