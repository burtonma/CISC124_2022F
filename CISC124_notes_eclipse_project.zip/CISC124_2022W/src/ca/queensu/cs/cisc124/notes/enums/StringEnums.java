package ca.queensu.cs.cisc124.notes.enums;

/**
 * An example of the string enum pattern. Java programmers should use a proper
 * enumeration instead.
 */
public class StringEnums {
	private StringEnums() {
		// private and empty by design
	}
	
	public static final String SUNDAY = "SUNDAY";
	public static final String MONDAY = "MONDAY";
	public static final String TUESDAY = "TUESDAY";
	public static final String WEDNESDAY = "WEDNESDAY";
	public static final String THURSDAY = "THURSDAY";
	public static final String FRIDAY = "FRIDAY";
	public static final String SATURDAY = "SATURDAY";
	
	public static final String JANUARY = "JANUARY";
	public static final String FEBRUARY = "FEBRUARY";
	public static final String MARCH = "MARCH";
	public static final String APRIL = "ARPIL";
	public static final String MAY = "MAY";
	public static final String JUNE = "JUNE";
	public static final String JULY = "JULY";
	public static final String AUGUST = "AUGUST";
	public static final String SEPTEMBER = "SEPTEMBER";
	public static final String OCTOBER = "OCTOBER";
	public static final String NOVEMBER = "NOVEMBER";
	public static final String DECEMBER = "DECEMBER";
}
